package com.example.bai6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnGoCurrency, btnGoLength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ các nút bấm
        btnGoCurrency = (Button) findViewById(R.id.btnGoCurrency);
        btnGoLength = (Button) findViewById(R.id.btnGoLength);

        // Xử lý sự kiện bấm nút đổi tiền
        btnGoCurrency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tạo một "ý định" để mở CurrencyActivity
                Intent intent = new Intent(MainActivity.this, CurrencyActivity.class);
                startActivity(intent); // Bắt đầu Activity mới
            }
        });

        // Xử lý sự kiện bấm nút đổi độ dài
        btnGoLength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tạo một "ý định" để mở LengthActivity
                Intent intent = new Intent(MainActivity.this, LengthActivity.class);
                startActivity(intent); // Bắt đầu Activity mới
            }
        });
    }
}