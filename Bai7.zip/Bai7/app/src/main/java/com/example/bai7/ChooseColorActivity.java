package com.example.bai7;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

public class ChooseColorActivity extends AppCompatActivity {

    SeekBar seekBarRed, seekBarGreen, seekBarBlue;
    TextView tvRed, tvGreen, tvBlue;
    View viewRGB, viewCMY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_color);

        // Ánh xạ các view
        seekBarRed = findViewById(R.id.seekBarRed);
        seekBarGreen = findViewById(R.id.seekBarGreen);
        seekBarBlue = findViewById(R.id.seekBarBlue);
        tvRed = findViewById(R.id.tvRed);
        tvGreen = findViewById(R.id.tvGreen);
        tvBlue = findViewById(R.id.tvBlue);
        viewRGB = findViewById(R.id.viewRGB);
        viewCMY = findViewById(R.id.viewCMY);

        // Tạo một listener chung cho cả 3 seekbar
        SeekBar.OnSeekBarChangeListener seekBarListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateColors();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        };

        // Gán listener cho cả 3 seekbar
        seekBarRed.setOnSeekBarChangeListener(seekBarListener);
        seekBarGreen.setOnSeekBarChangeListener(seekBarListener);
        seekBarBlue.setOnSeekBarChangeListener(seekBarListener);

        // Cập nhật màu ban đầu
        updateColors();
    }

    private void updateColors() {
        // Lấy giá trị từ Seekbar
        int r = seekBarRed.getProgress();
        int g = seekBarGreen.getProgress();
        int b = seekBarBlue.getProgress();

        // Cập nhật Text
        tvRed.setText("R: " + r);
        tvGreen.setText("G: " + g);
        tvBlue.setText("B: " + b);

        // Cập nhật màu cho View RGB
        viewRGB.setBackgroundColor(Color.rgb(r, g, b));

        // Tính toán và cập nhật màu cho View CMY [cite: 60, 61]
        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;
        viewCMY.setBackgroundColor(Color.rgb(c, m, y));
    }
}