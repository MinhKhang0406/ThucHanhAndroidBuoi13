package com.example.bai7;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnToast, btnDialog, btnOpenBai3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);
        btnOpenBai3 = findViewById(R.id.btnOpenBai3);

        // Xử lý sự kiện Bài tập 2 - Custom Toast
        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomToast();
            }
        });

        // Xử lý sự kiện Bài tập 2 - Custom Dialog
        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialog();
            }
        });

        // Xử lý sự kiện mở Bài tập 3
        btnOpenBai3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChooseColorActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast_layout,
                (ViewGroup) findViewById(R.id.custom_toast_container));

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

    private void showCustomDialog() {
        // Tạo đối tượng Dialog
        final Dialog dialog = new Dialog(this);
        // Nạp layout cho dialog
        dialog.setContentView(R.layout.custom_dialog_layout);

        // Bỏ tiêu đề mặc định của dialog
        dialog.setTitle("Đăng nhập");

        // Ánh xạ các view trong dialog
        Button btnDongY = dialog.findViewById(R.id.btnDialogDongY);
        Button btnThoat = dialog.findViewById(R.id.btnDialogThoat);

        // Xử lý sự kiện cho nút "ĐỒNG Ý"
        btnDongY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý logic đăng nhập (nếu cần)
                dialog.dismiss(); // Đóng dialog
            }
        });

        // Xử lý sự kiện cho nút "THOÁT"
        btnThoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss(); // Đóng dialog
            }
        });

        // Hiển thị dialog
        dialog.show();
    }
}