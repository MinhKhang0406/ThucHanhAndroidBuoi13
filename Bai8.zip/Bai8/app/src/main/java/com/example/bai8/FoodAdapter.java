package com.example.bai8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class FoodAdapter extends BaseAdapter {
    private ArrayList<Food> foodList;
    private Context context;

    public FoodAdapter(Context context, ArrayList<Food> foodList) {
        this.context = context;
        this.foodList = foodList;
    }

    @Override
    public int getCount() {
        return foodList.size();
    }

    @Override
    public Object getItem(int position) {
        return foodList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_food, parent, false);
        }

        Food food = foodList.get(position);

        ImageView imgFood = convertView.findViewById(R.id.imgFood);
        TextView txtFoodName = convertView.findViewById(R.id.txtFoodName);
        TextView txtFoodPrice = convertView.findViewById(R.id.txtFoodPrice);
        TextView txtFoodDescription = convertView.findViewById(R.id.txtFoodDescription);

        imgFood.setImageResource(food.image);
        txtFoodName.setText(food.name);
        txtFoodPrice.setText(food.price);
        txtFoodDescription.setText(food.description);

        return convertView;
    }
}