package com.example.bai8;

public class Food {
    public int image;
    public String name;
    public String price;
    public String description;

    public Food(int image, String name, String price, String description) {
        this.image = image;
        this.name = name;
        this.price = price;
        this.description = description;
    }
}