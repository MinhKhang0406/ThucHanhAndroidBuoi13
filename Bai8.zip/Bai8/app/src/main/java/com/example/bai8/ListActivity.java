package com.example.bai8;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    private ListView listViewFood;
    private ArrayList<Food> foodList;
    private FoodAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listViewFood = findViewById(R.id.listViewFood);
        initFoodData();

        adapter = new FoodAdapter(this, foodList);
        listViewFood.setAdapter(adapter);
    }

    private void initFoodData() {
        foodList = new ArrayList<>();
        foodList.add(new Food(R.drawable.food1, "Phở Hà Nội", "45.000 VNĐ", "Phở bò truyền thống Hà Nội"));
        foodList.add(new Food(R.drawable.food2, "Bún Chả", "40.000 VNĐ", "Bún chả Hà Nội đặc biệt"));
        foodList.add(new Food(R.drawable.food3, "Bánh Mì", "25.000 VNĐ", "Bánh mì thập cẩm"));
        foodList.add(new Food(R.drawable.food4, "Cơm Tấm", "35.000 VNĐ", "Cơm tấm sườn bì chả"));
        foodList.add(new Food(R.drawable.food5, "Bánh Xèo", "30.000 VNĐ", "Bánh xèo miền Nam"));
        foodList.add(new Food(R.drawable.food6, "Hủ Tiếu", "35.000 VNĐ", "Hủ tiếu Nam Vang"));
    }
}
