package com.example.bai8;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class CRUDActivity extends AppCompatActivity {
    private ListView listViewFood;
    private ArrayList<Food> foodList;
    private FoodAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud);

        listViewFood = findViewById(R.id.listViewFood);
        initFoodData();

        adapter = new FoodAdapter(this, foodList);
        listViewFood.setAdapter(adapter);

        registerForContextMenu(listViewFood);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_add) {
            showAddDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu_food, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;

        if (item.getItemId() == R.id.menu_edit) {
            showEditDialog(position);
            return true;
        } else if (item.getItemId() == R.id.menu_delete) {
            showDeleteDialog(position);
            return true;
        }
        return super.onContextItemSelected(item);
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_food, null);

        final EditText edtFoodName = dialogView.findViewById(R.id.edtFoodName);
        final EditText edtFoodPrice = dialogView.findViewById(R.id.edtFoodPrice);
        final EditText edtFoodDescription = dialogView.findViewById(R.id.edtFoodDescription);

        builder.setView(dialogView)
                .setTitle("Thêm món ăn")
                .setPositiveButton("Thêm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String name = edtFoodName.getText().toString();
                        String price = edtFoodPrice.getText().toString();
                        String description = edtFoodDescription.getText().toString();

                        if (!name.isEmpty() && !price.isEmpty()) {
                            foodList.add(new Food(R.drawable.food1, name, price + " VNĐ", description));
                            adapter.notifyDataSetChanged();
                            Toast.makeText(CRUDActivity.this, "Đã thêm món ăn", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(CRUDActivity.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showEditDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_food, null);

        final EditText edtFoodName = dialogView.findViewById(R.id.edtFoodName);
        final EditText edtFoodPrice = dialogView.findViewById(R.id.edtFoodPrice);
        final EditText edtFoodDescription = dialogView.findViewById(R.id.edtFoodDescription);

        Food food = foodList.get(position);
        edtFoodName.setText(food.name);
        edtFoodPrice.setText(food.price.replace(" VNĐ", ""));
        edtFoodDescription.setText(food.description);

        builder.setView(dialogView)
                .setTitle("Sửa món ăn")
                .setPositiveButton("Lưu", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String name = edtFoodName.getText().toString();
                        String price = edtFoodPrice.getText().toString();
                        String description = edtFoodDescription.getText().toString();

                        if (!name.isEmpty() && !price.isEmpty()) {
                            Food updatedFood = new Food(foodList.get(position).image, name, price + " VNĐ", description);
                            foodList.set(position, updatedFood);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(CRUDActivity.this, "Đã cập nhật món ăn", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(CRUDActivity.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showDeleteDialog(final int position) {
        new AlertDialog.Builder(this)
                .setTitle("Xóa món ăn")
                .setMessage("Bạn có chắc muốn xóa món ăn '" + foodList.get(position).name + "'?")
                .setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String deletedName = foodList.get(position).name;
                        foodList.remove(position);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(CRUDActivity.this, "Đã xóa món ăn: " + deletedName, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void initFoodData() {
        foodList = new ArrayList<>();
        foodList.add(new Food(R.drawable.food1, "Phở Hà Nội", "45.000 VNĐ", "Phở bò truyền thống Hà Nội"));
        foodList.add(new Food(R.drawable.food2, "Bún Chả", "40.000 VNĐ", "Bún chả Hà Nội đặc biệt"));
        foodList.add(new Food(R.drawable.food3, "Bánh Mì", "25.000 VNĐ", "Bánh mì thập cẩm"));
        foodList.add(new Food(R.drawable.food4, "Cơm Tấm", "35.000 VNĐ", "Cơm tấm sườn bì chả"));
    }
}