package com.example.bai8;

public class Contributor {
    public String name;
    public String points;
    public int avatar;

    public Contributor(String name, String points, int avatar) {
        this.name = name;
        this.points = points;
        this.avatar = avatar;
    }
}