package com.example.bai8;

import android.os.Bundle;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class GridActivity extends AppCompatActivity {
    private GridView gridView;
    private ArrayList<Contributor> contributorList;
    private ContributorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        gridView = findViewById(R.id.gridView);
        initContributorData();

        adapter = new ContributorAdapter(this, contributorList);
        gridView.setAdapter(adapter);
    }

    private void initContributorData() {
        contributorList = new ArrayList<>();
        contributorList.add(new Contributor("Maboo", "283,297", R.drawable.avatar1));
        contributorList.add(new Contributor("Brancon", "100,456", R.drawable.avatar2));
        contributorList.add(new Contributor("BBDS", "51,762", R.drawable.avatar3));
        contributorList.add(new Contributor("palacelight", "75,497", R.drawable.avatar4));
        contributorList.add(new Contributor("SameOldShawn", "252,433", R.drawable.avatar5));
        contributorList.add(new Contributor("Clement_RGF", "93,932", R.drawable.avatar6));
        contributorList.add(new Contributor("PleaseDe-ModMe", "79,243", R.drawable.avatar7));
        contributorList.add(new Contributor("TheDarkKnight", "69,193", R.drawable.avatar8));
        contributorList.add(new Contributor("Magrilude901", "164,935", R.drawable.avatar9));
        contributorList.add(new Contributor("Nebja", "84,187", R.drawable.avatar10));
        contributorList.add(new Contributor("DLizzle", "76,331", R.drawable.avatar11));
        contributorList.add(new Contributor("helirel", "68,903", R.drawable.avatar12));
    }
}